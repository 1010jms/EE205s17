#include <stdio.h>
#include <math.h>

#define PI 3.14

int calcAreaAndVolume(double rad, double *parea, double *pvolume);
