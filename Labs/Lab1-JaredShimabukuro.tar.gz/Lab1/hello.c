#include <stdio.h>

int main(){
	printf("\nGreetings, Professor Falken.\nShall we play a game?\nHow about a nice game of chess?\n\n\t\t-Joshua from War Games\n\n");
	return 0;
}
