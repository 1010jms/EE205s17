/* Lab 5 Task 1
 * Objective: Create a header file for grade-curve function
 *
 * Name: Jared Shimabukuro
 * UH ID: 2257-2949
 * Lab Section: 001
 *
 * Date Started: 2/7/17
 * Date Finished: 
 */

#include <iostream>
#include <math.h>
#include <vector>
using namespace std;

float mean(vector<int> grades, int count);
float stdev(vector<int> grades, float mean, int count);
